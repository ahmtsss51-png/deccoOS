--
-- PostgreSQL database dump
--

\restrict XvRD7XnRiRHk8KRDy52H2qgQRmLbwDWeqFt6pSAXjIHJJaBu59GwxkkfoxHZxM6

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: decco
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO decco;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: decco
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.accounts (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    account_type character varying(50) NOT NULL,
    balance numeric(14,2) DEFAULT 0,
    is_active boolean DEFAULT true
);


ALTER TABLE public.accounts OWNER TO decco;

--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accounts_id_seq OWNER TO decco;

--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.accounts_id_seq OWNED BY public.accounts.id;


--
-- Name: customer_payment_allocations; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.customer_payment_allocations (
    id integer NOT NULL,
    payment_id integer NOT NULL,
    order_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    CONSTRAINT customer_payment_allocations_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.customer_payment_allocations OWNER TO decco;

--
-- Name: customer_payment_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.customer_payment_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_payment_allocations_id_seq OWNER TO decco;

--
-- Name: customer_payment_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.customer_payment_allocations_id_seq OWNED BY public.customer_payment_allocations.id;


--
-- Name: customer_payments; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.customer_payments (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    account_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    method character varying(30),
    description text,
    paid_at timestamp with time zone DEFAULT now(),
    created_by integer,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT customer_payments_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.customer_payments OWNER TO decco;

--
-- Name: customer_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.customer_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_payments_id_seq OWNER TO decco;

--
-- Name: customer_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.customer_payments_id_seq OWNED BY public.customer_payments.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20),
    channel character varying(50),
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    city character varying(100),
    district character varying(100),
    address text,
    email character varying(200),
    is_active boolean DEFAULT true,
    deleted_at timestamp with time zone
);


ALTER TABLE public.customers OWNER TO decco;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO decco;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(20) DEFAULT 'blue'::character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.departments OWNER TO decco;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departments_id_seq OWNER TO decco;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: fixed_assets; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.fixed_assets (
    id integer NOT NULL,
    session_id integer,
    name character varying(200) NOT NULL,
    category character varying(100),
    purchase_date date,
    purchase_cost numeric(14,2) DEFAULT 0,
    in_service_date date,
    useful_life_months integer,
    opening_accumulated_depreciation numeric(14,2) DEFAULT 0,
    opening_carrying_value numeric(14,2) DEFAULT 0,
    payment_source character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    source character varying(20) DEFAULT 'OPENING'::character varying,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.fixed_assets OWNER TO decco;

--
-- Name: fixed_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.fixed_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fixed_assets_id_seq OWNER TO decco;

--
-- Name: fixed_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.fixed_assets_id_seq OWNED BY public.fixed_assets.id;


--
-- Name: materials; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.materials (
    id integer NOT NULL,
    sku character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    family character varying(100),
    color character varying(100),
    material_type character varying(50) NOT NULL,
    unit character varying(20) NOT NULL,
    current_stock numeric(12,4) DEFAULT 0,
    reserved_stock numeric(12,4) DEFAULT 0,
    avg_cost numeric(12,4) DEFAULT 0,
    reorder_level numeric(12,4),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.materials OWNER TO decco;

--
-- Name: materials_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.materials_id_seq OWNER TO decco;

--
-- Name: materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.materials_id_seq OWNED BY public.materials.id;


--
-- Name: opening_lines; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.opening_lines (
    id integer NOT NULL,
    session_id integer NOT NULL,
    section character varying(30) NOT NULL,
    ref_key character varying(100) NOT NULL,
    material_id integer,
    product_id integer,
    order_id integer,
    account_id integer,
    supplier_id integer,
    counted_qty numeric(12,4),
    unit_cost numeric(12,4),
    amount numeric(14,2),
    previous_value numeric(14,2),
    material_config jsonb,
    location character varying(100) DEFAULT 'ATOLYE'::character varying,
    status character varying(20) DEFAULT 'pending'::character varying,
    notes text,
    counted_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.opening_lines OWNER TO decco;

--
-- Name: opening_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.opening_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.opening_lines_id_seq OWNER TO decco;

--
-- Name: opening_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.opening_lines_id_seq OWNED BY public.opening_lines.id;


--
-- Name: opening_sessions; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.opening_sessions (
    id integer NOT NULL,
    go_live_date date,
    status character varying(20) DEFAULT 'draft'::character varying,
    confirmations jsonb DEFAULT '{}'::jsonb,
    locked_at timestamp with time zone,
    locked_by integer,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.opening_sessions OWNER TO decco;

--
-- Name: opening_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.opening_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.opening_sessions_id_seq OWNER TO decco;

--
-- Name: opening_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.opening_sessions_id_seq OWNED BY public.opening_sessions.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    variant_id integer,
    quantity integer DEFAULT 1,
    unit_price numeric(12,2) NOT NULL,
    discount numeric(12,2) DEFAULT 0,
    material_selections jsonb,
    personalization character varying(200),
    status character varying(50) DEFAULT 'pending'::character varying,
    notes text
);


ALTER TABLE public.order_items OWNER TO decco;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO decco;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    source character varying(50),
    status character varying(50) DEFAULT 'draft'::character varying,
    total_amount numeric(12,2) DEFAULT 0,
    paid_amount numeric(12,2) DEFAULT 0,
    notes text,
    order_date timestamp with time zone DEFAULT now(),
    delivery_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    order_no character varying(50),
    deleted_at timestamp with time zone,
    deleted_by integer,
    delete_reason text
);


ALTER TABLE public.orders OWNER TO decco;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO decco;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.product_variants (
    id integer NOT NULL,
    product_id integer NOT NULL,
    name character varying(100) NOT NULL,
    price_delta numeric(12,2) DEFAULT 0,
    is_active boolean DEFAULT true
);


ALTER TABLE public.product_variants OWNER TO decco;

--
-- Name: product_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.product_variants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_variants_id_seq OWNER TO decco;

--
-- Name: product_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.product_variants_id_seq OWNED BY public.product_variants.id;


--
-- Name: production_jobs; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.production_jobs (
    id integer NOT NULL,
    order_item_id integer,
    product_id integer NOT NULL,
    variant_id integer,
    recipe_id integer,
    quantity integer DEFAULT 1,
    status character varying(50) DEFAULT 'pending'::character varying,
    material_selections jsonb,
    notes text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.production_jobs OWNER TO decco;

--
-- Name: production_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.production_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_jobs_id_seq OWNER TO decco;

--
-- Name: production_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.production_jobs_id_seq OWNED BY public.production_jobs.id;


--
-- Name: production_outputs; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.production_outputs (
    id integer NOT NULL,
    job_id integer,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    material_config jsonb,
    unit_cost numeric(12,4),
    available_qty integer NOT NULL,
    produced_at timestamp with time zone DEFAULT now(),
    source character varying(20) DEFAULT 'PRODUCTION'::character varying,
    opening_line_id integer
);


ALTER TABLE public.production_outputs OWNER TO decco;

--
-- Name: production_outputs_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.production_outputs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.production_outputs_id_seq OWNER TO decco;

--
-- Name: production_outputs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.production_outputs_id_seq OWNED BY public.production_outputs.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.products (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    base_price numeric(12,2) DEFAULT 0,
    is_active boolean DEFAULT true,
    allows_personalization boolean DEFAULT false,
    standard_production_minutes integer DEFAULT 0,
    image_url character varying(500),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.products OWNER TO decco;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO decco;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: purchase_lines; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.purchase_lines (
    id integer NOT NULL,
    purchase_id integer NOT NULL,
    material_id integer NOT NULL,
    quantity numeric(12,4) NOT NULL,
    unit_cost numeric(12,4) NOT NULL
);


ALTER TABLE public.purchase_lines OWNER TO decco;

--
-- Name: purchase_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.purchase_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_lines_id_seq OWNER TO decco;

--
-- Name: purchase_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.purchase_lines_id_seq OWNED BY public.purchase_lines.id;


--
-- Name: purchase_return_lines; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.purchase_return_lines (
    id integer NOT NULL,
    return_id integer NOT NULL,
    material_id integer NOT NULL,
    quantity numeric(12,4) NOT NULL,
    unit_cost numeric(12,4) NOT NULL,
    CONSTRAINT purchase_return_lines_quantity_check CHECK ((quantity > (0)::numeric))
);


ALTER TABLE public.purchase_return_lines OWNER TO decco;

--
-- Name: purchase_return_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.purchase_return_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_return_lines_id_seq OWNER TO decco;

--
-- Name: purchase_return_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.purchase_return_lines_id_seq OWNED BY public.purchase_return_lines.id;


--
-- Name: purchase_returns; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.purchase_returns (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    purchase_id integer,
    total_amount numeric(14,2) DEFAULT 0 NOT NULL,
    settlement character varying(20) DEFAULT 'debt'::character varying NOT NULL,
    account_id integer,
    notes text,
    return_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.purchase_returns OWNER TO decco;

--
-- Name: purchase_returns_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.purchase_returns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_returns_id_seq OWNER TO decco;

--
-- Name: purchase_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.purchase_returns_id_seq OWNED BY public.purchase_returns.id;


--
-- Name: purchases; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.purchases (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    total_amount numeric(14,2) NOT NULL,
    paid_amount numeric(14,2) DEFAULT 0,
    purchase_date timestamp with time zone DEFAULT now(),
    notes text
);


ALTER TABLE public.purchases OWNER TO decco;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchases_id_seq OWNER TO decco;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: recipe_lines; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.recipe_lines (
    id integer NOT NULL,
    recipe_id integer NOT NULL,
    slot_code character varying(50) NOT NULL,
    slot_label character varying(100) NOT NULL,
    material_id integer,
    quantity numeric(10,4) NOT NULL,
    unit character varying(20) NOT NULL,
    waste_rate numeric(5,4) DEFAULT 0,
    customer_selectable boolean DEFAULT false
);


ALTER TABLE public.recipe_lines OWNER TO decco;

--
-- Name: recipe_lines_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.recipe_lines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recipe_lines_id_seq OWNER TO decco;

--
-- Name: recipe_lines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.recipe_lines_id_seq OWNED BY public.recipe_lines.id;


--
-- Name: recipes; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.recipes (
    id integer NOT NULL,
    product_id integer NOT NULL,
    variant_id integer,
    name character varying(100) DEFAULT 'Standart'::character varying,
    is_active boolean DEFAULT true,
    description text,
    updated_at timestamp with time zone DEFAULT now(),
    estimated_cost numeric(12,2)
);


ALTER TABLE public.recipes OWNER TO decco;

--
-- Name: recipes_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.recipes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recipes_id_seq OWNER TO decco;

--
-- Name: recipes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.recipes_id_seq OWNED BY public.recipes.id;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.stock_movements (
    id integer NOT NULL,
    material_id integer NOT NULL,
    movement_type character varying(50) NOT NULL,
    quantity numeric(12,4) NOT NULL,
    unit_cost numeric(12,4),
    reference_type character varying(50),
    reference_id integer,
    location character varying(100) DEFAULT 'ATOLYE'::character varying,
    notes text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.stock_movements OWNER TO decco;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.stock_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stock_movements_id_seq OWNER TO decco;

--
-- Name: stock_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.stock_movements_id_seq OWNED BY public.stock_movements.id;


--
-- Name: supplier_payments; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.supplier_payments (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    account_id integer NOT NULL,
    purchase_id integer,
    amount numeric(14,2) NOT NULL,
    description text,
    paid_at timestamp with time zone DEFAULT now(),
    created_by integer,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT supplier_payments_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.supplier_payments OWNER TO decco;

--
-- Name: supplier_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.supplier_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_payments_id_seq OWNER TO decco;

--
-- Name: supplier_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.supplier_payments_id_seq OWNED BY public.supplier_payments.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20),
    notes text,
    total_debt numeric(14,2) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    is_active boolean DEFAULT true,
    deleted_at timestamp with time zone,
    email character varying(200),
    address text,
    tax_no character varying(50)
);


ALTER TABLE public.suppliers OWNER TO decco;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_id_seq OWNER TO decco;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    account_id integer NOT NULL,
    amount numeric(14,2) NOT NULL,
    transaction_type character varying(50) NOT NULL,
    reference_type character varying(50),
    reference_id integer,
    description text,
    transaction_date timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.transactions OWNER TO decco;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transactions_id_seq OWNER TO decco;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: decco
--

CREATE TABLE public.users (
    id integer NOT NULL,
    full_name character varying(200) NOT NULL,
    username character varying(100) NOT NULL,
    password_hash text NOT NULL,
    role character varying(50) DEFAULT 'readonly'::character varying,
    department character varying(100),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO decco;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: decco
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO decco;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: decco
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.accounts ALTER COLUMN id SET DEFAULT nextval('public.accounts_id_seq'::regclass);


--
-- Name: customer_payment_allocations id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payment_allocations ALTER COLUMN id SET DEFAULT nextval('public.customer_payment_allocations_id_seq'::regclass);


--
-- Name: customer_payments id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payments ALTER COLUMN id SET DEFAULT nextval('public.customer_payments_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: fixed_assets id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.fixed_assets ALTER COLUMN id SET DEFAULT nextval('public.fixed_assets_id_seq'::regclass);


--
-- Name: materials id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.materials ALTER COLUMN id SET DEFAULT nextval('public.materials_id_seq'::regclass);


--
-- Name: opening_lines id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_lines ALTER COLUMN id SET DEFAULT nextval('public.opening_lines_id_seq'::regclass);


--
-- Name: opening_sessions id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_sessions ALTER COLUMN id SET DEFAULT nextval('public.opening_sessions_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: product_variants id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.product_variants ALTER COLUMN id SET DEFAULT nextval('public.product_variants_id_seq'::regclass);


--
-- Name: production_jobs id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_jobs ALTER COLUMN id SET DEFAULT nextval('public.production_jobs_id_seq'::regclass);


--
-- Name: production_outputs id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_outputs ALTER COLUMN id SET DEFAULT nextval('public.production_outputs_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: purchase_lines id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_lines ALTER COLUMN id SET DEFAULT nextval('public.purchase_lines_id_seq'::regclass);


--
-- Name: purchase_return_lines id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_return_lines ALTER COLUMN id SET DEFAULT nextval('public.purchase_return_lines_id_seq'::regclass);


--
-- Name: purchase_returns id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_returns ALTER COLUMN id SET DEFAULT nextval('public.purchase_returns_id_seq'::regclass);


--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: recipe_lines id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.recipe_lines ALTER COLUMN id SET DEFAULT nextval('public.recipe_lines_id_seq'::regclass);


--
-- Name: recipes id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.recipes ALTER COLUMN id SET DEFAULT nextval('public.recipes_id_seq'::regclass);


--
-- Name: stock_movements id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN id SET DEFAULT nextval('public.stock_movements_id_seq'::regclass);


--
-- Name: supplier_payments id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.supplier_payments ALTER COLUMN id SET DEFAULT nextval('public.supplier_payments_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.accounts (id, name, account_type, balance, is_active) FROM stdin;
1	Nakit	cash	0.00	t
2	Banka	bank	0.00	t
3	Kredi Kartı	card	0.00	t
\.


--
-- Data for Name: customer_payment_allocations; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.customer_payment_allocations (id, payment_id, order_id, amount) FROM stdin;
\.


--
-- Data for Name: customer_payments; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.customer_payments (id, customer_id, account_id, amount, method, description, paid_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.customers (id, name, phone, channel, notes, created_at, city, district, address, email, is_active, deleted_at) FROM stdin;
3	AYÇA MERAL	\N	direct	\N	2026-06-17 00:00:00+00	\N	\N	\N	\N	t	\N
6	Berat TEMİZSU	\N	instagram	\N	2026-07-02 00:00:00+00	\N	\N	\N	\N	t	\N
7	CEM GÜRSOY	\N	instagram	\N	2026-07-24 00:00:00+00	\N	\N	\N	\N	t	\N
10	ELİF ERGUÇ	\N	instagram	\N	2026-07-03 00:00:00+00	\N	\N	\N	\N	t	\N
11	EMİNE ZENGİN	\N	instagram	\N	2026-07-11 00:00:00+00	\N	\N	\N	\N	t	\N
12	EMRE ÇAKIL	\N	direct	\N	2026-08-01 00:00:00+00	\N	\N	\N	\N	t	\N
14	FATMA NUR BOLAT	\N	direct	\N	2026-07-17 00:00:00+00	\N	\N	\N	\N	t	\N
15	HALİL VİLLO	\N	instagram	\N	2026-07-18 00:00:00+00	\N	\N	\N	\N	t	\N
16	HÜSEYİN ERTAŞ	\N	direct	\N	2026-08-09 00:00:00+00	\N	\N	\N	\N	t	\N
19	MAHMUT AYDOĞAN	\N	instagram	\N	2026-07-04 00:00:00+00	\N	\N	\N	\N	t	\N
20	MEHMET ÖZ	\N	direct	\N	2026-08-07 00:00:00+00	\N	\N	\N	\N	t	\N
21	MOHAMMED JANABİ	\N	web	\N	2026-07-15 00:00:00+00	\N	\N	\N	\N	t	\N
22	MUSTAFA DURSUN ŞAHİN	\N	instagram	\N	2026-08-10 00:00:00+00	\N	\N	\N	\N	t	\N
25	NİHAT KOÇ	\N	web	\N	2026-07-15 00:00:00+00	\N	\N	\N	\N	t	\N
26	OKAN ŞİMŞEK	\N	instagram	\N	2026-07-25 00:00:00+00	\N	\N	\N	\N	t	\N
29	RECEP SAKİN	\N	direct	\N	2026-07-29 00:00:00+00	\N	\N	\N	\N	t	\N
30	SABİHA DEMİRÖZ	\N	direct	\N	2026-07-17 00:00:00+00	\N	\N	\N	\N	t	\N
31	SERVET TÜRKMEN	\N	direct	\N	2026-08-01 00:00:00+00	\N	\N	\N	\N	t	\N
33	TUNCAY TÜRKMENOĞLU	\N	instagram	\N	2026-07-16 00:00:00+00	\N	\N	\N	\N	t	\N
34	YASEMİN YAREN KARAKUŞ	\N	instagram	\N	2026-08-28 00:00:00+00	\N	\N	\N	\N	t	\N
35	ÇAĞRI UYSAL	\N	instagram	\N	2026-08-08 00:00:00+00	\N	\N	\N	\N	t	\N
36	ÇETİN UYSAL	\N	direct	\N	2026-08-25 00:00:00+00	\N	\N	\N	\N	t	\N
37	ÖZLEM BENGÜ PALAN	\N	instagram	\N	2026-08-02 00:00:00+00	\N	\N	\N	\N	t	\N
38	ŞEFİKA CEBE	\N	direct	\N	2026-08-28 00:00:00+00	\N	\N	\N	\N	t	\N
39	ŞENAY DİNÇER	\N	direct	\N	2026-08-01 00:00:00+00	\N	\N	\N	\N	t	\N
1	AHMET KURT	\N	direct	\N	2026-06-15 00:00:00+00	Niğde	\N	\N	\N	t	\N
2	ALMANYA	\N	direct	\N	2026-04-25 00:00:00+00	Almanya	\N	\N	\N	t	\N
4	AYŞENUR ÇELEN	507 688 19 14	instagram	\N	2026-05-17 00:00:00+00	Ankara	\N	\N	\N	t	\N
5	AZİM KANSOY	540 096 69 69	instagram	Tekrar müşteri	2026-04-24 00:00:00+00	İstanbul	\N	\N	\N	t	\N
8	CEMAL ÖZER	546 663 16 16	direct	\N	2026-05-08 00:00:00+00	Adana	\N	\N	\N	t	\N
9	DİLAVER ŞİMŞEK	\N	direct	Tekrar müşteri	2026-06-15 00:00:00+00	Niğde	\N	\N	\N	t	\N
13	FATİH ENGÜR	\N	direct	\N	2026-06-15 00:00:00+00	Niğde	\N	\N	\N	t	\N
17	IŞIKAY KORKMAZ	537 811 19 81	instagram	\N	2026-05-04 00:00:00+00	İstanbul	\N	\N	\N	t	\N
18	İBRAHİM BAYRAKÇI	535 856 27 72	instagram	Tekrar müşteri	2026-05-05 00:00:00+00	Hatay	\N	\N	\N	t	\N
23	NAZIM DAL	543 574 95 94	instagram	\N	2026-05-07 00:00:00+00	İstanbul	\N	\N	\N	t	\N
24	NAZLI YAĞMUROĞLU	552 417 25 83	instagram	\N	2026-05-17 00:00:00+00	Zonguldak	\N	\N	\N	t	\N
27	OSMAN DEMİR	\N	direct	Tekrar müşteri	2026-06-15 00:00:00+00	Niğde	\N	\N	\N	t	\N
28	PELİN SENA ÇELEBİLER	542 628 24 85	web	\N	2026-03-27 00:00:00+00	Ankara	\N	\N	\N	t	\N
32	SEVİDE SAYMAZ	542 421 57 69	instagram	\N	2026-06-26 00:00:00+00	Rize	\N	\N	\N	t	\N
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.departments (id, name, color, created_at) FROM stdin;
1	Yönetim	purple	2026-09-05 21:41:19.725604+00
2	Üretim	yellow	2026-09-05 21:41:19.725604+00
3	Satış	green	2026-09-05 21:41:19.725604+00
4	Finans	blue	2026-09-05 21:41:19.725604+00
5	Depo	gray	2026-09-05 21:41:19.725604+00
\.


--
-- Data for Name: fixed_assets; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.fixed_assets (id, session_id, name, category, purchase_date, purchase_cost, in_service_date, useful_life_months, opening_accumulated_depreciation, opening_carrying_value, payment_source, status, source, notes, created_at) FROM stdin;
\.


--
-- Data for Name: materials; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.materials (id, sku, name, family, color, material_type, unit, current_stock, reserved_stock, avg_cost, reorder_level, is_active, created_at) FROM stdin;
1	CR-CML	Crazy Camel	CRAZY	Camel	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
2	CR-KHV	Crazy Kahve	CRAZY	Kahve	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
3	CR-KRM	Crazy Kırmızı	CRAZY	Kırmızı	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
4	CR-MOR	Crazy Mor	CRAZY	Mor	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
5	CR-SYH	Crazy Siyah	CRAZY	Siyah	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
6	CR-YSL	Crazy Yeşil	CRAZY	Yeşil	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
7	KM-CML	Kaşmir Camel	KASMIR	Camel	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
8	KM-KRM	Kaşmir Kırmızı	KASMIR	Kırmızı	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
9	KM-MOR	Kaşmir Mor	KASMIR	Mor	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
10	KM-SYH	Kaşmir Siyah	KASMIR	Siyah	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
11	KM-YSL	Kaşmir Yeşil	KASMIR	Yeşil	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
12	PB-CML	Pueblo Camel	PUEBLO	Camel	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
13	PB-KKH	Pueblo Kızıl Kahve	PUEBLO	Kızıl Kahve	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
14	PB-KNY	Pueblo Konyak	PUEBLO	Konyak	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
15	PB-YSL	Pueblo Yeşil	PUEBLO	Yeşil	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
16	TI-ASF	Tiana Asfalt	TIANA	Asfalt	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
17	TI-GRI	Tiana Gri	TIANA	Gri	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
18	TI-YSL	Tiana Yeşil	TIANA	Yeşil	leather	desi	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
19	ADH-DENLAKS-250ML	Denlaks 250 ml	LEATHER_GLUE	\N	adhesive	ml	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
20	ADH-DERBY-WHITE-100G	Derby Beyaz 100 g	LEATHER_GLUE	\N	adhesive	gram	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
21	CON-SADDLE-NEEDLE	Saraç İğnesi	NEEDLE	\N	consumable	adet	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
22	HW-CARD-MECH	Kart Mekanizması	\N	\N	accessory	adet	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
23	HW-MONEY-CLIP	Para Klipsi	\N	\N	accessory	adet	0.0000	0.0000	0.0000	\N	t	2026-09-06 20:27:00.595996+00
\.


--
-- Data for Name: opening_lines; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.opening_lines (id, session_id, section, ref_key, material_id, product_id, order_id, account_id, supplier_id, counted_qty, unit_cost, amount, previous_value, material_config, location, status, notes, counted_at, updated_at) FROM stdin;
1	1	material	1	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
2	1	material	2	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
3	1	material	3	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
4	1	material	4	4	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
5	1	material	5	5	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
6	1	material	6	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
7	1	material	7	7	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
8	1	material	8	8	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
9	1	material	9	9	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
10	1	material	10	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
11	1	material	11	11	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
12	1	material	12	12	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
13	1	material	13	13	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
14	1	material	14	14	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
15	1	material	15	15	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
16	1	material	16	16	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
17	1	material	17	17	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
18	1	material	18	18	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
19	1	material	19	19	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
20	1	material	20	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
21	1	material	21	21	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
22	1	material	22	22	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
23	1	material	23	23	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:23.987202+00
24	1	account	1	\N	\N	\N	1	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.017569+00
25	1	account	2	\N	\N	\N	2	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.017569+00
26	1	account	3	\N	\N	\N	3	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.017569+00
27	1	receivable	9	\N	\N	9	\N	\N	\N	\N	1800.00	1800.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.025329+00
28	1	receivable	22	\N	\N	22	\N	\N	\N	\N	1250.00	1250.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.025329+00
29	1	receivable	41	\N	\N	41	\N	\N	\N	\N	600.00	600.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.025329+00
30	1	receivable	42	\N	\N	42	\N	\N	\N	\N	1850.00	1850.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.025329+00
31	1	supplier_debt	1	\N	\N	\N	\N	1	\N	\N	\N	0.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.040026+00
32	1	supplier_debt	2	\N	\N	\N	\N	2	\N	\N	\N	0.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.040026+00
33	1	supplier_debt	3	\N	\N	\N	\N	3	\N	\N	\N	0.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.040026+00
34	1	supplier_debt	4	\N	\N	\N	\N	4	\N	\N	\N	0.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.040026+00
35	1	supplier_debt	5	\N	\N	\N	\N	5	\N	\N	\N	0.00	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.040026+00
36	1	founder	FOUNDER	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	ATOLYE	pending	\N	\N	2026-09-06 20:41:24.048021+00
\.


--
-- Data for Name: opening_sessions; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.opening_sessions (id, go_live_date, status, confirmations, locked_at, locked_by, notes, created_at) FROM stdin;
1	\N	draft	{}	\N	\N	\N	2026-09-06 20:41:23.974905+00
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.order_items (id, order_id, product_id, variant_id, quantity, unit_price, discount, material_selections, personalization, status, notes) FROM stdin;
1	1	7	\N	1	899.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-001 · Katlanır Çapraz · Kaynak maliyet: 220.00 TL
2	2	5	\N	1	1750.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-CML", "main_leather_id": 1, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-002 · Double Portföy · Kaynak maliyet: 300.00 TL
3	3	7	\N	2	1500.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}, {"unit": "2", "main_leather": "PB-YSL", "main_leather_id": 15, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE/YEŞİL	completed	HST-003 · Katlanır Çapraz · Maliyet girilecek
4	4	8	\N	1	1250.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-YSL", "main_leather_id": 6, "secondary_leather": "PB-CML", "secondary_leather_id": 12}]}	YEŞİL/SARI	completed	HST-004 · Katlanır Köşegen · Maliyet girilecek
5	5	8	\N	3	1050.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}, {"unit": "2", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}, {"unit": "3", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	\N	completed	HST-005 · Katlanır Köşegen · Maliyet girilecek
6	6	13	\N	1	650.00	0.00	{"units": [{"unit": "1", "main_leather": null, "main_leather_id": null, "secondary_leather": null, "secondary_leather_id": null}]}	\N	completed	HST-006 · Özel üretim kartlık (şeffaf içli) · ÖZEL / KATALOG DIŞI · Maliyet girilecek
7	7	6	\N	2	750.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}, {"unit": "2", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-007 · Katlanır Model · Kaynak maliyet: 440.00 TL
8	8	5	\N	1	1500.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-CML", "main_leather_id": 12, "secondary_leather": null, "secondary_leather_id": null}]}	SARI	completed	HST-008 · Double Portföy · Kaynak maliyet: 300.00 TL
9	8	1	\N	1	900.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-CML", "main_leather_id": 12, "secondary_leather": null, "secondary_leather_id": null}]}	SARI	completed	HST-009 · Klasik Cüzdan · Kaynak maliyet: 220.00 TL
10	9	13	\N	2	900.00	0.00	{"units": [{"unit": "1", "main_leather": null, "main_leather_id": null, "secondary_leather": null, "secondary_leather_id": null}, {"unit": "2", "main_leather": null, "main_leather_id": null, "secondary_leather": null, "secondary_leather_id": null}]}	\N	completed	HST-010 · Özel üretim kartlık · ÖZEL / KATALOG DIŞI · Maliyet girilecek
11	10	13	\N	1	550.00	0.00	{"units": [{"unit": "1", "main_leather": null, "main_leather_id": null, "secondary_leather": null, "secondary_leather_id": null}]}	YÜZÜK	completed	HST-011 · Özel üretim yüzük · ÖZEL / KATALOG DIŞI · Maliyet girilecek
12	11	6	\N	1	950.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	PUEBLO KAHVE	completed	HST-012 · Katlanır Model · Kaynak maliyet: 220.00 TL
13	17	11	\N	1	1200.00	0.00	{"units": [{"unit": "1", "main_leather": "KM-YSL", "main_leather_id": 11, "secondary_leather": null, "secondary_leather_id": null}]}	YEŞİL	completed	HST-013 · Portföy · Kaynak maliyet: 250.00 TL
14	12	5	\N	1	1000.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-YSL", "main_leather_id": 15, "secondary_leather": null, "secondary_leather_id": null}]}	HAKİ	completed	HST-014 · Double Portföy · Kaynak maliyet: 300.00 TL
15	12	1	\N	1	500.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-YSL", "main_leather_id": 15, "secondary_leather": null, "secondary_leather_id": null}]}	HAKİ	completed	HST-015 · Klasik Cüzdan · Kaynak maliyet: 220.00 TL
16	13	6	\N	1	650.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-016 · Katlanır Model · Kaynak maliyet: 220.00 TL
17	14	6	\N	1	650.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-017 · Katlanır Model · Kaynak maliyet: 220.00 TL
18	15	1	\N	2	300.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}, {"unit": "2", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-018 · Klasik Cüzdan · Kaynak maliyet: 440.00 TL
19	18	11	\N	1	1200.00	0.00	{"units": [{"unit": "1", "main_leather": "KM-YSL", "main_leather_id": 11, "secondary_leather": null, "secondary_leather_id": null}]}	YEŞİL	completed	HST-019 · Portföy · Kaynak maliyet: 250.00 TL
20	19	11	\N	1	1200.00	0.00	{"units": [{"unit": "1", "main_leather": "KM-YSL", "main_leather_id": 11, "secondary_leather": null, "secondary_leather_id": null}]}	YEŞİL	completed	HST-020 · Portföy · Kaynak maliyet: 250.00 TL
21	20	1	\N	1	950.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KKH", "main_leather_id": 13, "secondary_leather": null, "secondary_leather_id": null}]}	MUSTANG	completed	HST-021 · Klasik Cüzdan · Kaynak maliyet: 220.00 TL
22	21	5	\N	1	1500.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-MOR", "main_leather_id": 4, "secondary_leather": null, "secondary_leather_id": null}]}	MOR	completed	HST-022 · Double Portföy · Kaynak maliyet: 300.00 TL
23	21	9	\N	1	2000.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-MOR", "main_leather_id": 4, "secondary_leather": null, "secondary_leather_id": null}]}	MOR	completed	HST-023 · MacBook Kılıfı · Kaynak maliyet: 600.00 TL
24	22	5	\N	1	1250.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-CML", "main_leather_id": 1, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-024 · Double Portföy · Kaynak maliyet: 300.00 TL
25	23	5	\N	1	1800.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-MOR", "main_leather_id": 4, "secondary_leather": null, "secondary_leather_id": null}]}	MOR	completed	HST-025 · Double Portföy · Kaynak maliyet: 300.00 TL
26	24	5	\N	1	1650.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-CML", "main_leather_id": 1, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-026 · Double Portföy · Kaynak maliyet: 300.00 TL
27	25	7	\N	1	899.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-YSL", "main_leather_id": 15, "secondary_leather": null, "secondary_leather_id": null}]}	HAKİ	completed	HST-027 · Katlanır Çapraz · Maliyet girilecek
28	26	5	\N	1	1600.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	completed	HST-028 · Double Portföy · Kaynak maliyet: 300.00 TL
29	27	11	\N	2	750.00	0.00	{"units": [{"unit": "1", "main_leather": "KM-CML", "main_leather_id": 7, "secondary_leather": null, "secondary_leather_id": null}, {"unit": "2", "main_leather": "KM-KRM", "main_leather_id": 8, "secondary_leather": null, "secondary_leather_id": null}]}	BORDO/KAHVE	completed	HST-029 · Portföy · Kaynak maliyet: 500.00 TL
30	27	2	\N	1	600.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	completed	HST-030 · Klasik Dikey · Kaynak maliyet: 220.00 TL
31	27	2	\N	1	600.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KKH", "main_leather_id": 13, "secondary_leather": null, "secondary_leather_id": null}]}	MUSTANG	completed	HST-031 · Klasik Dikey · Kaynak maliyet: 220.00 TL
32	28	1	\N	1	950.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	completed	HST-032 · Klasik Cüzdan · Kaynak maliyet: 220.00 TL
33	29	5	\N	1	1650.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KKH", "main_leather_id": 13, "secondary_leather": null, "secondary_leather_id": null}]}	KIZIL KAHVE	completed	HST-033 · Double Portföy · Kaynak maliyet: 300.00 TL
34	30	11	\N	1	1200.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	shipped	HST-034 · Portföy · Kaynak maliyet: 250.00 TL
35	31	5	\N	1	1850.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KKH", "main_leather_id": 13, "secondary_leather": null, "secondary_leather_id": null}]}	KIZIL KAHVE	shipped	HST-035 · Double Portföy · Kaynak maliyet: 300.00 TL
36	16	5	\N	1	1550.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-CML", "main_leather_id": 12, "secondary_leather": null, "secondary_leather_id": null}]}	SARI	completed	HST-036 · Double Portföy · Kaynak maliyet: 300.00 TL
37	32	3	\N	1	200.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	siyah	completed	HST-037 · Klasik Çıtçıtlı · Maliyet girilecek
38	33	5	\N	1	2000.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-CML", "main_leather_id": 12, "secondary_leather": null, "secondary_leather_id": null}]}	SARI	completed	HST-038 · Double Portföy · Kaynak maliyet: 300.00 TL
39	33	3	\N	1	1000.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	completed	HST-039 · Klasik Çıtçıtlı · Maliyet girilecek
40	34	3	\N	1	600.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": "CR-CML", "secondary_leather_id": 1}]}	SİYAH-KAHVE	completed	HST-040 · Klasik Çıtçıtlı · Maliyet girilecek
41	35	1	\N	1	600.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	completed	HST-041 · Klasik Cüzdan · Kaynak maliyet: 220.00 TL
42	36	13	\N	1	1500.00	0.00	{"units": [{"unit": "1", "main_leather": null, "main_leather_id": null, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	completed	HST-042 · Özel üretim fermuarlı cüzdan · ÖZEL / KATALOG DIŞI · Maliyet girilecek
43	37	3	\N	1	200.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": "CR-CML", "secondary_leather_id": 1}]}	SİYAH-KAHVE	completed	HST-043 · Klasik Çıtçıtlı · Maliyet girilecek
44	38	7	\N	1	950.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE	completed	HST-044 · Katlanır Çapraz · Maliyet girilecek
45	40	10	\N	1	500.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-CML", "main_leather_id": 1, "secondary_leather": null, "secondary_leather_id": null}]}	KAHVE/MİNİ KARTLIK	completed	HST-045 · Mini Çıtçıtlı Kartlık · Maliyet girilecek
46	39	6	\N	1	600.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	completed	HST-046 · Katlanır Model · Kaynak maliyet: 220.00 TL
47	41	2	\N	1	600.00	0.00	{"units": [{"unit": "1", "main_leather": "CR-SYH", "main_leather_id": 5, "secondary_leather": null, "secondary_leather_id": null}]}	SİYAH	completed	HST-047 · Klasik Dikey · Kaynak maliyet: 220.00 TL
48	42	5	\N	1	1850.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KNY", "main_leather_id": 14, "secondary_leather": null, "secondary_leather_id": null}]}	KONYAK	ready	HST-048 · Double Portföy · Kaynak maliyet: 300.00 TL
49	43	12	\N	1	1250.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KKH", "main_leather_id": 13, "secondary_leather": null, "secondary_leather_id": null}]}	KIZIL KAHVE	ready	HST-049 · Pasaport Kılıfı · Maliyet girilecek
50	43	13	\N	1	500.00	0.00	{"units": [{"unit": "1", "main_leather": "PB-KKH", "main_leather_id": 13, "secondary_leather": null, "secondary_leather_id": null}]}	KIZIL KAHVE	ready	HST-050 · Özel anahtarlık (Deniz Kabuğu şekilli) · ÖZEL / KATALOG DIŞI · Maliyet girilecek
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.orders (id, customer_id, source, status, total_amount, paid_amount, notes, order_date, delivery_date, created_at, order_no, deleted_at, deleted_by, delete_reason) FROM stdin;
1	28	web	completed	899.00	899.00	2603-001 · Kredi Kartı · ANKARA	2026-03-27 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2603-001	\N	\N	\N
2	5	instagram	completed	1750.00	1750.00	2604-001 · Banka Havalesi · İSTANBUL	2026-04-24 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2604-001	\N	\N	\N
3	2	direct	completed	3000.00	3000.00	2604-002 · Nakit · ALMANYA	2026-04-25 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2604-002	\N	\N	\N
4	17	instagram	completed	1250.00	1250.00	2605-001 · Banka Havalesi · İSTANBUL	2026-05-04 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2605-001	\N	\N	\N
5	18	instagram	completed	3150.00	3150.00	2605-002 · Banka Havalesi · HATAY	2026-05-05 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2605-002	\N	\N	\N
6	23	instagram	completed	650.00	650.00	2605-003 · Banka Havalesi · İSTANBUL	2026-05-07 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2605-003	\N	\N	\N
7	8	direct	completed	1500.00	1500.00	2605-004 · Banka Havalesi · ADANA	2026-05-08 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2605-004	\N	\N	\N
8	5	instagram	completed	2400.00	2400.00	2605-005 · Banka Havalesi · İSTANBUL	2026-05-15 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2605-005	\N	\N	\N
9	18	instagram	completed	1800.00	0.00	2605-006 · Banka Havalesi · HATAY	2026-05-16 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2605-006	\N	\N	\N
10	24	instagram	completed	550.00	550.00	2605-007 · Banka Havalesi · ZONGULDAK	2026-05-17 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2605-007	\N	\N	\N
11	4	instagram	completed	950.00	950.00	2605-008 · Banka Havalesi · ANKARA	2026-05-17 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2605-008	\N	\N	\N
12	13	direct	completed	1500.00	1500.00	2606-02 · Nakit · NİĞDE	2026-06-15 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2606-02	\N	\N	\N
13	9	direct	completed	650.00	650.00	2606-03 · Nakit · NİĞDE	2026-06-15 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2606-03	\N	\N	\N
14	27	direct	completed	650.00	650.00	2606-04 · Nakit · NİĞDE	2026-06-15 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2606-04	\N	\N	\N
15	1	direct	completed	600.00	600.00	2606-05 · Nakit · NİĞDE	2026-06-15 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2606-05	\N	\N	\N
16	3	direct	completed	1550.00	1550.00	2607-015 · Banka Havalesi	2026-06-17 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-015	\N	\N	\N
17	32	instagram	completed	1200.00	1200.00	2606-01 · Banka Havalesi · RİZE	2026-06-26 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2606-01	\N	\N	\N
18	27	direct	completed	1200.00	1200.00	2607-001 · Nakit · Niğde	2026-07-01 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-001	\N	\N	\N
19	6	instagram	completed	1200.00	1200.00	2607-002 · Banka Havalesi	2026-07-02 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-002	\N	\N	\N
20	10	instagram	completed	950.00	950.00	2607-003 · Banka Havalesi	2026-07-03 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-003	\N	\N	\N
21	19	instagram	completed	3500.00	3500.00	2607-004 · Banka Havalesi	2026-07-04 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-004	\N	\N	\N
22	9	direct	completed	1250.00	0.00	2607-005 · Nakit · NİĞDE	2026-07-06 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-005	\N	\N	\N
23	11	instagram	completed	1800.00	1800.00	2607-006 · Banka Havalesi	2026-07-11 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-006	\N	\N	\N
24	21	web	completed	1650.00	1650.00	2607-007 · Kredi Kartı	2026-07-15 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-007	\N	\N	\N
25	25	web	completed	899.00	899.00	2607-008 · Kredi Kartı	2026-07-15 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-008	\N	\N	\N
26	33	instagram	completed	1600.00	1600.00	2607-009 · Banka Havalesi	2026-07-16 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-009	\N	\N	\N
27	14	direct	completed	2700.00	2700.00	2607-010 · Nakit	2026-07-17 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-010	\N	\N	\N
28	30	direct	completed	950.00	950.00	2607-011 · Banka Havalesi	2026-07-17 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-011	\N	\N	\N
29	15	instagram	completed	1650.00	1650.00	2607-012 · Banka Havalesi	2026-07-18 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-012	\N	\N	\N
30	7	instagram	shipped	1200.00	1200.00	2607-013 · Banka Havalesi	2026-07-24 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-013	\N	\N	\N
31	26	instagram	shipped	1850.00	1850.00	2607-014 · Banka Havalesi	2026-07-25 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-014	\N	\N	\N
32	29	direct	completed	200.00	200.00	2607-016 · Nakit	2026-07-29 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2607-016	\N	\N	\N
33	39	direct	completed	3000.00	3000.00	2608-001 · Nakit	2026-08-01 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-001	\N	\N	\N
34	12	direct	completed	600.00	600.00	2608-002 · Nakit	2026-08-01 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-002	\N	\N	\N
35	31	direct	completed	600.00	600.00	2608-003 · Nakit	2026-08-01 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-003	\N	\N	\N
36	37	instagram	completed	1500.00	1500.00	2608-004 · Banka Havalesi	2026-08-02 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-004	\N	\N	\N
37	20	direct	completed	200.00	200.00	2608-005 · Nakit	2026-08-07 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-005	\N	\N	\N
38	35	instagram	completed	950.00	950.00	2608-006 · Banka Havalesi	2026-08-08 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-006	\N	\N	\N
39	16	direct	completed	600.00	600.00	2608-008 · Nakit	2026-08-09 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-008	\N	\N	\N
40	22	instagram	completed	500.00	500.00	2608-007 · Banka Havalesi	2026-08-10 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-007	\N	\N	\N
41	36	direct	completed	600.00	0.00	2608-009 · Nakit	2026-08-25 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-009	\N	\N	\N
42	38	direct	ready	1850.00	0.00	2608-010 · Banka Havalesi	2026-08-28 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-010	\N	\N	\N
43	34	instagram	ready	1750.00	1750.00	2608-011 · Banka Havalesi	2026-08-28 00:00:00+00	\N	2026-09-06 20:27:00.595996+00	2608-011	\N	\N	\N
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.product_variants (id, product_id, name, price_delta, is_active) FROM stdin;
\.


--
-- Data for Name: production_jobs; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.production_jobs (id, order_item_id, product_id, variant_id, recipe_id, quantity, status, material_selections, notes, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: production_outputs; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.production_outputs (id, job_id, product_id, quantity, material_config, unit_cost, available_qty, produced_at, source, opening_line_id) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.products (id, code, name, description, base_price, is_active, allows_personalization, standard_production_minutes, image_url, created_at) FROM stdin;
1	CW001	Klasik Cüzdan	Kategori: Klasik Cüzdan	600.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
2	CW002	Klasik Dikey	Kategori: Klasik Cüzdan	600.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
3	CW003	Klasik Çıtçıtlı	Kategori: Klasik Cüzdan	200.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
4	CW004	Klasik Dikey Çıtçıtlı	Kategori: Klasik Cüzdan	0.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
5	DP001	Double Portföy	Kategori: Portföy	1850.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
6	FW001	Katlanır Model	Kategori: Katlanır Cüzdan	600.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
7	FW002	Katlanır Çapraz	Kategori: Katlanır Cüzdan	950.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
8	FW003	Katlanır Köşegen	Kategori: Katlanır Cüzdan	1050.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
9	MB001	MacBook Kılıfı	Kategori: Kılıf	2000.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
10	MC001	Mini Çıtçıtlı Kartlık	Kategori: Kartlık	500.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
11	PF001	Portföy	Kategori: Portföy	1200.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
12	PW001	Pasaport Kılıfı	Kategori: Kılıf	1250.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
13	SPECIAL	Özel Üretim	Katalog dışı gerçek özel üretim; ürün kodu uydurulmadı	0.00	t	t	0	\N	2026-09-06 20:27:00.595996+00
\.


--
-- Data for Name: purchase_lines; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.purchase_lines (id, purchase_id, material_id, quantity, unit_cost) FROM stdin;
\.


--
-- Data for Name: purchase_return_lines; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.purchase_return_lines (id, return_id, material_id, quantity, unit_cost) FROM stdin;
\.


--
-- Data for Name: purchase_returns; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.purchase_returns (id, supplier_id, purchase_id, total_amount, settlement, account_id, notes, return_date, created_at) FROM stdin;
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.purchases (id, supplier_id, total_amount, paid_amount, purchase_date, notes) FROM stdin;
\.


--
-- Data for Name: recipe_lines; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.recipe_lines (id, recipe_id, slot_code, slot_label, material_id, quantity, unit, waste_rate, customer_selectable) FROM stdin;
\.


--
-- Data for Name: recipes; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.recipes (id, product_id, variant_id, name, is_active, description, updated_at, estimated_cost) FROM stdin;
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.stock_movements (id, material_id, movement_type, quantity, unit_cost, reference_type, reference_id, location, notes, created_at) FROM stdin;
\.


--
-- Data for Name: supplier_payments; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.supplier_payments (id, supplier_id, account_id, purchase_id, amount, description, paid_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.suppliers (id, name, phone, notes, total_debt, created_at, is_active, deleted_at, email, address, tax_no) FROM stdin;
1	ALİ KARAYAZI	\N	\N	0.00	2026-09-06 20:27:00.595996+00	t	\N	\N	\N	\N
2	meta	\N	\N	0.00	2026-09-06 20:27:00.595996+00	t	\N	\N	\N	\N
3	vaketa deri	\N	\N	0.00	2026-09-06 20:27:00.595996+00	t	\N	\N	\N	\N
4	hepsiburada	\N	\N	0.00	2026-09-06 20:27:00.595996+00	t	\N	\N	\N	\N
5	KARGONOMİ	\N	\N	0.00	2026-09-06 20:27:00.595996+00	t	\N	\N	\N	\N
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.transactions (id, account_id, amount, transaction_type, reference_type, reference_id, description, transaction_date, created_at) FROM stdin;
1	3	899.00	customer_payment	order	1	2603-001 tahsilat — PELİN SENA ÇELEBİLER	2026-03-27 00:00:00+00	2026-09-06 20:27:00.595996+00
2	2	1750.00	customer_payment	order	2	2604-001 tahsilat — AZİM KANSOY	2026-04-24 00:00:00+00	2026-09-06 20:27:00.595996+00
3	1	3000.00	customer_payment	order	3	2604-002 tahsilat — ALMANYA	2026-04-25 00:00:00+00	2026-09-06 20:27:00.595996+00
4	2	1250.00	customer_payment	order	4	2605-001 tahsilat — IŞIKAY KORKMAZ	2026-05-04 00:00:00+00	2026-09-06 20:27:00.595996+00
5	2	3150.00	customer_payment	order	5	2605-002 tahsilat — İBRAHİM BAYRAKÇI	2026-05-05 00:00:00+00	2026-09-06 20:27:00.595996+00
6	2	650.00	customer_payment	order	6	2605-003 tahsilat — NAZIM DAL	2026-05-07 00:00:00+00	2026-09-06 20:27:00.595996+00
7	2	1500.00	customer_payment	order	7	2605-004 tahsilat — CEMAL ÖZER	2026-05-08 00:00:00+00	2026-09-06 20:27:00.595996+00
8	2	2400.00	customer_payment	order	8	2605-005 tahsilat — AZİM KANSOY	2026-05-15 00:00:00+00	2026-09-06 20:27:00.595996+00
9	2	550.00	customer_payment	order	10	2605-007 tahsilat — NAZLI YAĞMUROĞLU	2026-05-17 00:00:00+00	2026-09-06 20:27:00.595996+00
10	2	950.00	customer_payment	order	11	2605-008 tahsilat — AYŞENUR ÇELEN	2026-05-17 00:00:00+00	2026-09-06 20:27:00.595996+00
11	1	1500.00	customer_payment	order	12	2606-02 tahsilat — FATİH ENGÜR	2026-06-15 00:00:00+00	2026-09-06 20:27:00.595996+00
12	1	650.00	customer_payment	order	13	2606-03 tahsilat — DİLAVER ŞİMŞEK	2026-06-15 00:00:00+00	2026-09-06 20:27:00.595996+00
13	1	650.00	customer_payment	order	14	2606-04 tahsilat — OSMAN DEMİR	2026-06-15 00:00:00+00	2026-09-06 20:27:00.595996+00
14	1	600.00	customer_payment	order	15	2606-05 tahsilat — AHMET KURT	2026-06-15 00:00:00+00	2026-09-06 20:27:00.595996+00
15	2	1550.00	customer_payment	order	16	2607-015 tahsilat — AYÇA MERAL	2026-06-17 00:00:00+00	2026-09-06 20:27:00.595996+00
16	2	1200.00	customer_payment	order	17	2606-01 tahsilat — SEVİDE SAYMAZ	2026-06-26 00:00:00+00	2026-09-06 20:27:00.595996+00
17	1	1200.00	customer_payment	order	18	2607-001 tahsilat — Osman DEMİR	2026-07-01 00:00:00+00	2026-09-06 20:27:00.595996+00
18	2	1200.00	customer_payment	order	19	2607-002 tahsilat — Berat TEMİZSU	2026-07-02 00:00:00+00	2026-09-06 20:27:00.595996+00
19	2	950.00	customer_payment	order	20	2607-003 tahsilat — ELİF ERGUÇ	2026-07-03 00:00:00+00	2026-09-06 20:27:00.595996+00
20	2	3500.00	customer_payment	order	21	2607-004 tahsilat — MAHMUT AYDOĞAN	2026-07-04 00:00:00+00	2026-09-06 20:27:00.595996+00
21	2	1800.00	customer_payment	order	23	2607-006 tahsilat — EMİNE ZENGİN	2026-07-11 00:00:00+00	2026-09-06 20:27:00.595996+00
22	3	1650.00	customer_payment	order	24	2607-007 tahsilat — MOHAMMED JANABİ	2026-07-15 00:00:00+00	2026-09-06 20:27:00.595996+00
23	3	899.00	customer_payment	order	25	2607-008 tahsilat — NİHAT KOÇ	2026-07-15 00:00:00+00	2026-09-06 20:27:00.595996+00
24	2	1600.00	customer_payment	order	26	2607-009 tahsilat — TUNCAY TÜRKMENOĞLU	2026-07-16 00:00:00+00	2026-09-06 20:27:00.595996+00
25	1	2700.00	customer_payment	order	27	2607-010 tahsilat — FATMA NUR BOLAT	2026-07-17 00:00:00+00	2026-09-06 20:27:00.595996+00
26	2	950.00	customer_payment	order	28	2607-011 tahsilat — SABİHA DEMİRÖZ	2026-07-17 00:00:00+00	2026-09-06 20:27:00.595996+00
27	2	1650.00	customer_payment	order	29	2607-012 tahsilat — HALİL VİLLO	2026-07-18 00:00:00+00	2026-09-06 20:27:00.595996+00
28	2	1200.00	customer_payment	order	30	2607-013 tahsilat — CEM GÜRSOY	2026-07-24 00:00:00+00	2026-09-06 20:27:00.595996+00
29	2	1850.00	customer_payment	order	31	2607-014 tahsilat — OKAN ŞİMŞEK	2026-07-25 00:00:00+00	2026-09-06 20:27:00.595996+00
30	1	200.00	customer_payment	order	32	2607-016 tahsilat — RECEP SAKİN	2026-07-29 00:00:00+00	2026-09-06 20:27:00.595996+00
31	1	3000.00	customer_payment	order	33	2608-001 tahsilat — ŞENAY DİNÇER	2026-08-01 00:00:00+00	2026-09-06 20:27:00.595996+00
32	1	600.00	customer_payment	order	34	2608-002 tahsilat — EMRE ÇAKIL	2026-08-01 00:00:00+00	2026-09-06 20:27:00.595996+00
33	1	600.00	customer_payment	order	35	2608-003 tahsilat — SERVET TÜRKMEN	2026-08-01 00:00:00+00	2026-09-06 20:27:00.595996+00
34	2	1500.00	customer_payment	order	36	2608-004 tahsilat — ÖZLEM BENGÜ PALAN	2026-08-02 00:00:00+00	2026-09-06 20:27:00.595996+00
35	1	200.00	customer_payment	order	37	2608-005 tahsilat — MEHMET ÖZ	2026-08-07 00:00:00+00	2026-09-06 20:27:00.595996+00
36	2	950.00	customer_payment	order	38	2608-006 tahsilat — ÇAĞRI UYSAL	2026-08-08 00:00:00+00	2026-09-06 20:27:00.595996+00
37	1	600.00	customer_payment	order	39	2608-008 tahsilat — HÜSEYİN ERTAŞ	2026-08-09 00:00:00+00	2026-09-06 20:27:00.595996+00
38	2	500.00	customer_payment	order	40	2608-007 tahsilat — MUSTAFA DURSUN ŞAHİN	2026-08-10 00:00:00+00	2026-09-06 20:27:00.595996+00
39	2	1750.00	customer_payment	order	43	2608-011 tahsilat — YASEMİN YAREN KARAKUŞ	2026-08-28 00:00:00+00	2026-09-06 20:27:00.595996+00
40	2	-8900.00	expense	supplier	1	GDR-001 · Deri & Sarf Malzemesi — ALİ KARAYAZI	2026-07-02 00:00:00+00	2026-09-06 20:27:00.595996+00
41	2	-1550.00	expense	supplier	1	GDR-002 · Deri & Sarf Malzemesi — ALİ KARAYAZI	2026-02-13 00:00:00+00	2026-09-06 20:27:00.595996+00
42	2	-2965.00	expense	supplier	1	GDR-003 · Deri & Sarf Malzemesi — ALİ KARAYAZI	2026-03-31 00:00:00+00	2026-09-06 20:27:00.595996+00
43	2	-2200.00	expense	supplier	1	GDR-004 · Deri & Sarf Malzemesi — ALİ KARAYAZI	2026-04-30 00:00:00+00	2026-09-06 20:27:00.595996+00
44	2	-3000.00	expense	supplier	1	GDR-005 · Deri & Sarf Malzemesi — ALİ KARAYAZI	2026-05-18 00:00:00+00	2026-09-06 20:27:00.595996+00
45	3	-2137.73	expense	supplier	2	GDR-006 · Reklam — meta	2026-04-30 00:00:00+00	2026-09-06 20:27:00.595996+00
46	3	-6058.29	expense	supplier	2	GDR-007 · Reklam — meta	2026-05-30 00:00:00+00	2026-09-06 20:27:00.595996+00
47	3	-6601.90	expense	supplier	2	GDR-008 · Reklam — meta	2026-06-30 00:00:00+00	2026-09-06 20:27:00.595996+00
48	3	-865.00	expense	supplier	3	GDR-009 · Deri & Sarf Malzemesi — vaketa deri	2026-05-04 00:00:00+00	2026-09-06 20:27:00.595996+00
49	3	-1503.50	expense	supplier	4	GDR-010 · Paketleme — hepsiburada	2026-07-22 00:00:00+00	2026-09-06 20:27:00.595996+00
50	3	-7527.94	expense	supplier	2	GDR-011 · Reklam — meta	2026-07-30 00:00:00+00	2026-09-06 20:27:00.595996+00
51	2	-6700.00	expense	supplier	1	GDR-012 · Deri & Sarf Malzemesi — ALİ KARAYAZI	2026-07-27 00:00:00+00	2026-09-06 20:27:00.595996+00
52	2	-3160.00	expense	supplier	1	GDR-013 · Deri & Sarf Malzemesi — ALİ KARAYAZI	2026-08-08 00:00:00+00	2026-09-06 20:27:00.595996+00
53	3	-1235.44	expense	supplier	5	GDR-014 · Kargo — KARGONOMİ	2026-07-30 00:00:00+00	2026-09-06 20:27:00.595996+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: decco
--

COPY public.users (id, full_name, username, password_hash, role, department, is_active, created_at) FROM stdin;
1	Yönetici	admin	$2a$10$LU26uY.FMiEgk.6D4b07bOqVI1IeYmMr0eNqpqO7NYSjWhIXctZZ.	admin	Yönetim	t	2026-09-05 21:41:19.725604+00
\.


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.accounts_id_seq', 3, true);


--
-- Name: customer_payment_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.customer_payment_allocations_id_seq', 1, false);


--
-- Name: customer_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.customer_payments_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.customers_id_seq', 42, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.departments_id_seq', 65, true);


--
-- Name: fixed_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.fixed_assets_id_seq', 1, false);


--
-- Name: materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.materials_id_seq', 23, true);


--
-- Name: opening_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.opening_lines_id_seq', 468, true);


--
-- Name: opening_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.opening_sessions_id_seq', 1, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.order_items_id_seq', 50, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.orders_id_seq', 43, true);


--
-- Name: product_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.product_variants_id_seq', 1, false);


--
-- Name: production_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.production_jobs_id_seq', 1, false);


--
-- Name: production_outputs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.production_outputs_id_seq', 1, false);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.products_id_seq', 13, true);


--
-- Name: purchase_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.purchase_lines_id_seq', 1, false);


--
-- Name: purchase_return_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.purchase_return_lines_id_seq', 1, false);


--
-- Name: purchase_returns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.purchase_returns_id_seq', 1, false);


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.purchases_id_seq', 1, false);


--
-- Name: recipe_lines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.recipe_lines_id_seq', 1, false);


--
-- Name: recipes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.recipes_id_seq', 1, false);


--
-- Name: stock_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.stock_movements_id_seq', 1, false);


--
-- Name: supplier_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.supplier_payments_id_seq', 1, false);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 5, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.transactions_id_seq', 53, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: decco
--

SELECT pg_catalog.setval('public.users_id_seq', 13, true);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: customer_payment_allocations customer_payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payment_allocations
    ADD CONSTRAINT customer_payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: customer_payments customer_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: departments departments_name_key; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_name_key UNIQUE (name);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: fixed_assets fixed_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_pkey PRIMARY KEY (id);


--
-- Name: materials materials_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_pkey PRIMARY KEY (id);


--
-- Name: materials materials_sku_key; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.materials
    ADD CONSTRAINT materials_sku_key UNIQUE (sku);


--
-- Name: opening_lines opening_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_lines
    ADD CONSTRAINT opening_lines_pkey PRIMARY KEY (id);


--
-- Name: opening_sessions opening_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_sessions
    ADD CONSTRAINT opening_sessions_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: production_jobs production_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_jobs
    ADD CONSTRAINT production_jobs_pkey PRIMARY KEY (id);


--
-- Name: production_outputs production_outputs_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_outputs
    ADD CONSTRAINT production_outputs_pkey PRIMARY KEY (id);


--
-- Name: products products_code_key; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_code_key UNIQUE (code);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_lines purchase_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_lines
    ADD CONSTRAINT purchase_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_return_lines purchase_return_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_return_lines
    ADD CONSTRAINT purchase_return_lines_pkey PRIMARY KEY (id);


--
-- Name: purchase_returns purchase_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: recipe_lines recipe_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.recipe_lines
    ADD CONSTRAINT recipe_lines_pkey PRIMARY KEY (id);


--
-- Name: recipes recipes_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: supplier_payments supplier_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: cpa_order_idx; Type: INDEX; Schema: public; Owner: decco
--

CREATE INDEX cpa_order_idx ON public.customer_payment_allocations USING btree (order_id);


--
-- Name: opening_lines_uniq; Type: INDEX; Schema: public; Owner: decco
--

CREATE UNIQUE INDEX opening_lines_uniq ON public.opening_lines USING btree (session_id, section, ref_key);


--
-- Name: opening_sessions_single_open; Type: INDEX; Schema: public; Owner: decco
--

CREATE UNIQUE INDEX opening_sessions_single_open ON public.opening_sessions USING btree (((locked_at IS NULL))) WHERE (locked_at IS NULL);


--
-- Name: orders_active_idx; Type: INDEX; Schema: public; Owner: decco
--

CREATE INDEX orders_active_idx ON public.orders USING btree (order_date DESC) WHERE (deleted_at IS NULL);


--
-- Name: production_outputs_opening_uniq; Type: INDEX; Schema: public; Owner: decco
--

CREATE UNIQUE INDEX production_outputs_opening_uniq ON public.production_outputs USING btree (opening_line_id) WHERE (opening_line_id IS NOT NULL);


--
-- Name: purchase_returns_sup_idx; Type: INDEX; Schema: public; Owner: decco
--

CREATE INDEX purchase_returns_sup_idx ON public.purchase_returns USING btree (supplier_id, return_date DESC);


--
-- Name: stock_movements_opening_uniq; Type: INDEX; Schema: public; Owner: decco
--

CREATE UNIQUE INDEX stock_movements_opening_uniq ON public.stock_movements USING btree (material_id, reference_id) WHERE ((reference_type)::text = 'OPENING'::text);


--
-- Name: supplier_payments_sup_idx; Type: INDEX; Schema: public; Owner: decco
--

CREATE INDEX supplier_payments_sup_idx ON public.supplier_payments USING btree (supplier_id, paid_at DESC);


--
-- Name: transactions_opening_uniq; Type: INDEX; Schema: public; Owner: decco
--

CREATE UNIQUE INDEX transactions_opening_uniq ON public.transactions USING btree (account_id, reference_id) WHERE ((transaction_type)::text = 'opening_balance'::text);


--
-- Name: transactions_order_reversal_uniq; Type: INDEX; Schema: public; Owner: decco
--

CREATE UNIQUE INDEX transactions_order_reversal_uniq ON public.transactions USING btree (reference_id, account_id) WHERE ((reference_type)::text = 'order_reversal'::text);


--
-- Name: customer_payment_allocations customer_payment_allocations_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payment_allocations
    ADD CONSTRAINT customer_payment_allocations_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: customer_payment_allocations customer_payment_allocations_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payment_allocations
    ADD CONSTRAINT customer_payment_allocations_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.customer_payments(id) ON DELETE CASCADE;


--
-- Name: customer_payments customer_payments_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: customer_payments customer_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: customer_payments customer_payments_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: fixed_assets fixed_assets_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.fixed_assets
    ADD CONSTRAINT fixed_assets_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.opening_sessions(id);


--
-- Name: opening_lines opening_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_lines
    ADD CONSTRAINT opening_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: opening_lines opening_lines_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_lines
    ADD CONSTRAINT opening_lines_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: opening_lines opening_lines_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_lines
    ADD CONSTRAINT opening_lines_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: opening_lines opening_lines_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_lines
    ADD CONSTRAINT opening_lines_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: opening_lines opening_lines_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_lines
    ADD CONSTRAINT opening_lines_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.opening_sessions(id) ON DELETE CASCADE;


--
-- Name: opening_lines opening_lines_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_lines
    ADD CONSTRAINT opening_lines_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: opening_sessions opening_sessions_locked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.opening_sessions
    ADD CONSTRAINT opening_sessions_locked_by_fkey FOREIGN KEY (locked_by) REFERENCES public.users(id);


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: order_items order_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: orders orders_deleted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_deleted_by_fkey FOREIGN KEY (deleted_by) REFERENCES public.users(id);


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: production_jobs production_jobs_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_jobs
    ADD CONSTRAINT production_jobs_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES public.order_items(id);


--
-- Name: production_jobs production_jobs_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_jobs
    ADD CONSTRAINT production_jobs_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: production_jobs production_jobs_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_jobs
    ADD CONSTRAINT production_jobs_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id);


--
-- Name: production_jobs production_jobs_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_jobs
    ADD CONSTRAINT production_jobs_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: production_outputs production_outputs_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_outputs
    ADD CONSTRAINT production_outputs_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.production_jobs(id);


--
-- Name: production_outputs production_outputs_opening_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_outputs
    ADD CONSTRAINT production_outputs_opening_line_id_fkey FOREIGN KEY (opening_line_id) REFERENCES public.opening_lines(id);


--
-- Name: production_outputs production_outputs_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.production_outputs
    ADD CONSTRAINT production_outputs_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: purchase_lines purchase_lines_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_lines
    ADD CONSTRAINT purchase_lines_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: purchase_lines purchase_lines_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_lines
    ADD CONSTRAINT purchase_lines_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id) ON DELETE CASCADE;


--
-- Name: purchase_return_lines purchase_return_lines_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_return_lines
    ADD CONSTRAINT purchase_return_lines_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: purchase_return_lines purchase_return_lines_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_return_lines
    ADD CONSTRAINT purchase_return_lines_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.purchase_returns(id) ON DELETE CASCADE;


--
-- Name: purchase_returns purchase_returns_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: purchase_returns purchase_returns_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id);


--
-- Name: purchase_returns purchase_returns_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: purchases purchases_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: recipe_lines recipe_lines_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.recipe_lines
    ADD CONSTRAINT recipe_lines_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: recipe_lines recipe_lines_recipe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.recipe_lines
    ADD CONSTRAINT recipe_lines_recipe_id_fkey FOREIGN KEY (recipe_id) REFERENCES public.recipes(id);


--
-- Name: recipes recipes_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: recipes recipes_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.recipes
    ADD CONSTRAINT recipes_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: stock_movements stock_movements_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_material_id_fkey FOREIGN KEY (material_id) REFERENCES public.materials(id);


--
-- Name: supplier_payments supplier_payments_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: supplier_payments supplier_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: supplier_payments supplier_payments_purchase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES public.purchases(id);


--
-- Name: supplier_payments supplier_payments_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: transactions transactions_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: decco
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: decco
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict XvRD7XnRiRHk8KRDy52H2qgQRmLbwDWeqFt6pSAXjIHJJaBu59GwxkkfoxHZxM6

